package com.poo.lab3.model;

public enum TipoTarea {
    SIMPLE,
    CON_FECHA_LIMITE
}