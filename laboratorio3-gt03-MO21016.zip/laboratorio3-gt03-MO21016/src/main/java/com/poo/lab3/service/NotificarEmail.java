package com.poo.lab3.service;

import com.poo.lab3.model.Tarea;
import org.springframework.stereotype.Service;

@Service
public class NotificarEmail implements IAccionAlCompletar {

    @Override
    public String ejecutar(Tarea tarea) {
        return "EMAIL: Notificando que la tarea '" + tarea.getDescripcion() + "' fue completada";
    }

    @Override
    public String getTipoAccion() {
        return "email";
    }
}