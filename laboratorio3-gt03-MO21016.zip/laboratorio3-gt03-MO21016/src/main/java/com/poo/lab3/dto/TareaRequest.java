package com.poo.lab3.dto;

import com.poo.lab3.model.TipoTarea;
import lombok.Data;

@Data
public class TareaRequest {
    private String descripcion;
    private TipoTarea tipo;
    private String fechaLimite; // Opcional, será null si es SIMPLE
}