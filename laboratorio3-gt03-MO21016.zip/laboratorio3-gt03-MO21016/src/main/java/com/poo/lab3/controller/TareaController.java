package com.poo.lab3.controller;

import com.poo.lab3.dto.CompletarTareaResponse;
import com.poo.lab3.dto.TareaRequest;
import com.poo.lab3.dto.TareaResponse;
import com.poo.lab3.service.TareaService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tareas")
@RequiredArgsConstructor
public class TareaController {

    private final TareaService tareaService;

    // Endpoint 1: POST /api/tareas - Crear tarea
    @PostMapping
    public TareaResponse crearTarea(@RequestBody TareaRequest request) {
        return tareaService.crearTarea(request);
    }

    // Endpoint 2: GET /api/tareas/pendientes - Ver tareas pendientes
    @GetMapping("/pendientes")
    public List<TareaResponse> getTareasPendientes() {
        return tareaService.getTareasPendientes();
    }

    // Endpoint 3: PATCH /api/tareas/{id}/completar?accion=email
    @PatchMapping("/{id}/completar")
    public CompletarTareaResponse completarTarea(
            @PathVariable Long id,
            @RequestParam String accion) {
        return tareaService.marcarTareaComoCompletada(id, accion);
    }
}