package com.poo.lab3.service;

import com.poo.lab3.dto.CompletarTareaResponse;
import com.poo.lab3.dto.TareaRequest;
import com.poo.lab3.dto.TareaResponse;
import com.poo.lab3.model.Tarea;
import com.poo.lab3.model.TipoTarea;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class TareaService {

    // Simulación de base de datos
    private final Map<Long, Tarea> baseDatos = new HashMap<>();
    private Long idCounter = 1L;

    // Mapa de estrategias inyectado por Spring
    private final Map<String, IAccionAlCompletar> acciones;

    // Constructor: Spring inyecta todas las implementaciones de IAccionAlCompletar
    public TareaService(List<IAccionAlCompletar> listaAcciones) {
        this.acciones = new HashMap<>();
        for (IAccionAlCompletar accion : listaAcciones) {
            acciones.put(accion.getTipoAccion(), accion);
        }
    }

    // Método 1: Crear una tarea
    public TareaResponse crearTarea(TareaRequest dto) {
        // Convertir DTO a entidad
        Tarea tarea = new Tarea();
        tarea.setId(idCounter++);
        tarea.setDescripcion(dto.getDescripcion());
        tarea.setCompletada(false);
        tarea.setTipo(dto.getTipo());
        tarea.setFechaLimite(dto.getFechaLimite());

        // Guardar en el "mapa-base de datos"
        baseDatos.put(tarea.getId(), tarea);

        // Convertir entidad a TareaResponse
        return convertirATareaResponse(tarea);
    }

    // Método 2: Obtener tareas pendientes
    public List<TareaResponse> getTareasPendientes() {
        return baseDatos.values().stream()
                .filter(tarea -> !tarea.isCompletada())
                .map(this::convertirATareaResponse)
                .collect(Collectors.toList());
    }

    // Método 3: Marcar tarea como completada (AQUÍ SE USA EL POLIMORFISMO)
    public CompletarTareaResponse marcarTareaComoCompletada(Long id, String tipoAccion) {
        // Paso 1: Buscar la tarea
        Tarea tarea = baseDatos.get(id);
        if (tarea == null) {
            throw new RuntimeException("Tarea no encontrada con id: " + id);
        }

        // Paso 2: Obtener la acción correcta del mapa (POLIMORFISMO)
        IAccionAlCompletar accion = acciones.get(tipoAccion);
        if (accion == null) {
            throw new RuntimeException("Acción no válida: " + tipoAccion);
        }

        // Paso 3: Marcar como completada
        tarea.setCompletada(true);

        // Paso 4: Ejecutar la acción (polimorfismo en acción)
        String mensajeAccion = accion.ejecutar(tarea);

        // Paso 5: Devolver respuesta
        TareaResponse tareaResponse = convertirATareaResponse(tarea);
        return new CompletarTareaResponse(tareaResponse, mensajeAccion);
    }

    // Método auxiliar: Convierte Tarea a TareaResponse (implementa "mostrarDetalles")
    private TareaResponse convertirATareaResponse(Tarea tarea) {
        String detalles;

        // Aquí está el polimorfismo de "mostrarDetalles()"
        if (tarea.getTipo() == TipoTarea.SIMPLE) {
            detalles = "[Simple] " + tarea.getDescripcion();
        } else {
            detalles = "[Urgente] " + tarea.getDescripcion() +
                    " (Límite: " + tarea.getFechaLimite() + ")";
        }

        return new TareaResponse(tarea.getId(), tarea.isCompletada(), detalles);
    }
}