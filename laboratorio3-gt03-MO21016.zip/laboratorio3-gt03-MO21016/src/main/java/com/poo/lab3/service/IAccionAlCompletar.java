package com.poo.lab3.service;

import com.poo.lab3.model.Tarea;

public interface IAccionAlCompletar {
    String ejecutar(Tarea tarea);
    String getTipoAccion(); // Clave para la inyección de Spring
}