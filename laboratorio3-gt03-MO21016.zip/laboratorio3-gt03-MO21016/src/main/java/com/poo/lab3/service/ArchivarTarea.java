package com.poo.lab3.service;

import com.poo.lab3.model.Tarea;
import org.springframework.stereotype.Service;

@Service
public class ArchivarTarea implements IAccionAlCompletar {

    @Override
    public String ejecutar(Tarea tarea) {
        return "ARCHIVO: Moviendo tarea '" + tarea.getDescripcion() + "' al archivo histórico";
    }

    @Override
    public String getTipoAccion() {
        return "archivar";
    }
}