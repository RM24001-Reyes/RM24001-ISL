package com.poo.lab3.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CompletarTareaResponse {
    private TareaResponse tarea;
    private String accionEjecutada; // Ejemplo: "EMAIL: Notificando..."
}