package com.cursos.Cursos.Online.model;

public enum EstadoCurso {
    ACTIVO,
    INACTIVO,
    FINALIZADO;
}
