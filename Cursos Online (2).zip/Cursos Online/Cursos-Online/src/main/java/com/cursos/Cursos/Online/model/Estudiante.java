package com.cursos.Cursos.Online.model;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToMany;
import lombok.Data;

@Data
@Entity
public class Estudiante extends Usuario {

    @ManyToMany(mappedBy = "estudiantesInscritos")
    private List<Curso> cursosInscritos;
}
