package com.cursos.Cursos.Online.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.util.List;

@Data
@Entity
@EqualsAndHashCode(callSuper = true)
public class Instructor extends Usuario {

    @OneToMany(mappedBy = "instructor", cascade = CascadeType.ALL)
    private List<Curso> cursosCreados;
}
