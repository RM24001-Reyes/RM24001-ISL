package com.cursos.Cursos.Online.model;

public enum Rol {
    ESTUDIANTE,
    INSTRUCTOR

}
